import py7zr, os

def extract_all(input_dir, output_dir):
    for file in os.listdir(input_dir):
        if file.endswith(".7z"):
            print(f"Extracting {file}")
            with py7zr.SevenZipFile(os.path.join(input_dir, file), 'r') as archive:
                archive.extractall(path=output_dir)
    print("✅ All extracted.")

if __name__ == "__main__":
    extract_all("project", "data/eth3d")
