import os
import cv2
import torch
import numpy as np

def load_midas_model(device):
    model_type = "DPT_Large"  # or DPT_Hybrid

    # Load model
    model = torch.hub.load("intel-isl/MiDaS", model_type)
    model.to(device)
    model.eval()

    # Load transforms
    transforms = torch.hub.load("intel-isl/MiDaS", "transforms")

    if model_type == "DPT_Large" or model_type == "DPT_Hybrid":
        transform = transforms.dpt_transform
    else:
        transform = transforms.small_transform

    return model, transform

def run_midas(image_dir, output_dir):
    # ✅ Device selection
    if torch.backends.mps.is_available():
        device = torch.device("mps")
    elif torch.cuda.is_available():
        device = torch.device("cuda")
    else:
        device = torch.device("cpu")

    model, transform = load_midas_model(device)
    os.makedirs(output_dir, exist_ok=True)

    for img_name in os.listdir(image_dir):
        if not img_name.lower().endswith((".jpg", ".jpeg", ".png")):
            continue

        img_path = os.path.join(image_dir, img_name)
        img = cv2.imread(img_path)
        img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

        # ✅ Robust transform application
        result = transform(img_rgb)
        print("🔍 transform() output type:", type(result))
        if isinstance(result, dict):
            print("✅ keys:", result.keys())
            print("✅ tensor shape:", result["image"].shape)
        else:
            print("✅ tensor shape:", result.shape)


        # This will handle both dict and tensor
        if isinstance(result, dict):
            input_tensor = result["image"].to(device)
        else:
            input_tensor = result.to(device)

        print("📏 Final input tensor shape:", input_tensor.shape)  # Debug

        with torch.no_grad():
            prediction = model(input_tensor)
            prediction = torch.nn.functional.interpolate(
                prediction.unsqueeze(1),
                size=img.shape[:2],
                mode="bicubic",
                align_corners=False,
            ).squeeze()

        # Normalize
        depth_map = prediction.cpu().numpy()
        depth_map = cv2.normalize(depth_map, None, 0, 255, cv2.NORM_MINMAX)
        depth_map = depth_map.astype(np.uint8)

        out_path = os.path.join(
            output_dir,
            img_name.replace(".jpg", "_depth.png")
                    .replace(".jpeg", "_depth.png")
                    .replace(".JPG", "_depth.png")
        )
        cv2.imwrite(out_path, depth_map)

    print("✅ MiDaS depth maps saved to:", output_dir)
print ("hello")