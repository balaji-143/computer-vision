import os
from colmap_runner import run_colmap
from midas_depth import run_midas
from evaluate_metrics import evaluate

scene_root = os.path.join(os.path.dirname(__file__), "../data/eth3d")
output_root = os.path.join(os.path.dirname(__file__), "../outputs")

for scene in os.listdir(scene_root):
    if scene.startswith("."):  # ✅ Skip hidden files like .DS_Store
        continue

    scene_path = os.path.join(scene_root, scene)
    if not os.path.isdir(scene_path):  # ✅ Only process folders
        continue

    image_path = os.path.join(scene_path, "images")
    gt_path = os.path.join(scene_path, "dslr_scan_eval")
    out_path = os.path.join(output_root, scene)
    depth_out = os.path.join(out_path, "midas_depth")

    print(f"🚀 Processing: {scene}")
    run_colmap(scene_path, out_path)
    run_midas(image_path, depth_out)

    if os.path.exists(gt_path):
        metrics = evaluate(depth_out, gt_path)
        with open(os.path.join(out_path, "metrics.txt"), "w") as f:
            f.write(str(metrics))
