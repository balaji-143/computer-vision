import os
import shutil

SCENE_ROOT = os.path.join("data", "eth3d")
OUTPUT_ROOT = "outputs"

def prepare_sparse_model(scene):
    src_sparse = os.path.join(OUTPUT_ROOT, scene, "sparse", "0")
    dst_sparse = os.path.join(OUTPUT_ROOT, scene, "dense", "sparse")
    os.makedirs(dst_sparse, exist_ok=True)

    for file in ["cameras.bin", "images.bin", "points3D.bin"]:
        src = os.path.join(src_sparse, file)
        dst = os.path.join(dst_sparse, file)
        if os.path.exists(src):
            shutil.copy(src, dst)

def prepare_stereo_workspace(scene):
    stereo_dir = os.path.join(OUTPUT_ROOT, scene, "dense", "stereo")
    os.makedirs(stereo_dir, exist_ok=True)

    image_dir = os.path.join(SCENE_ROOT, scene, "dslr_images")
    image_list_file = os.path.join(stereo_dir, "images.txt")

    with open(image_list_file, "w") as f:
        for img in sorted(os.listdir(image_dir)):
            if img.lower().endswith((".jpg", ".jpeg", ".png")):
                f.write(f"{img}\n")

    fusion_cfg_path = os.path.join(stereo_dir, "fusion.cfg")
    open(fusion_cfg_path, "a").close()

def run_dense_reconstruction(scene):
    dense_path = os.path.join(OUTPUT_ROOT, scene, "dense")
    print(f"\n🚧 Running Dense Reconstruction for: {scene}")

    prepare_sparse_model(scene)
    prepare_stereo_workspace(scene)

    cmd = f"colmap stereo_fusion --workspace_path {dense_path} --workspace_format COLMAP --input_type geometric --output_path {os.path.join(dense_path, 'fused.ply')}"
    result = os.system(cmd)

    if result == 0:
        print(f"🎯 Dense fused.ply generated for {scene}")
    else:
        print(f"❌ Dense fusion failed for {scene}")

if __name__ == "__main__":
    scenes = [d for d in os.listdir(SCENE_ROOT) if os.path.isdir(os.path.join(SCENE_ROOT, d))]
    for scene in scenes:
        run_dense_reconstruction(scene)
