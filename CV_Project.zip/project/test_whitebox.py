import unittest
import os

class TestSceneExplorerLogic(unittest.TestCase):
    def setUp(self):
        self.scene_root = "outputs"
        self.scene_name = "courtyard"
        self.fused_path = os.path.join(self.scene_root, self.scene_name, "dense", "fused.ply")
        self.metrics_path = os.path.join(self.scene_root, self.scene_name, "metrics.txt")

    def test_scene_folder_exists(self):
        self.assertTrue(os.path.isdir(os.path.join(self.scene_root, self.scene_name)))

    def test_fused_path_exists(self):
        self.assertTrue(os.path.exists(self.fused_path), "fused.ply file missing!")

    def test_metrics_readable(self):
        self.assertTrue(os.path.exists(self.metrics_path), "metrics.txt file not found")
        with open(self.metrics_path, "r") as f:
            contents = f.read()
            self.assertIn("RMSE", contents)
            self.assertIn("SSIM", contents)

if __name__ == "__main__":
    unittest.main()
