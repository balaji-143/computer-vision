import os
import numpy as np
import cv2
from skimage.metrics import structural_similarity as ssim, peak_signal_noise_ratio as psnr

# === CONFIG PATHS ===
SCENE_ROOT = os.path.join(os.path.dirname(__file__), "../data/eth3d")
OUTPUT_ROOT = os.path.join(os.path.dirname(__file__), "../outputs")

def read_gt_depth(gt_path):
    """Reads ETH3D ground truth depth stored as float32 with .JPG extension"""
    try:
        with open(gt_path, 'rb') as f:
            data = f.read()
        depth_array = np.frombuffer(data, dtype=np.float32).copy()

        side = int(np.sqrt(depth_array.size))
        depth_image = depth_array[:side * side].reshape((side, side))
        depth_image[np.isinf(depth_image)] = 0
        return depth_image
    except Exception as e:
        print(f"❌ Error reading GT depth: {gt_path} | {e}")
        return None

def evaluate(scene_name, gt_dir, pred_dir):
    metrics = {
        "RMSE": [], "MAE": [], "NRMSE": [],
        "MAPE": [], "SSIM": [], "PSNR": [], "Correlation": []
    }

    for gt_file in os.listdir(gt_dir):
        if not gt_file.endswith(".JPG"):
            continue

        base_name = os.path.splitext(gt_file)[0]
        pred_file = base_name + "_depth.png"
        pred_path = os.path.join(pred_dir, pred_file)
        gt_path = os.path.join(gt_dir, gt_file)

        if not os.path.exists(pred_path):
            print(f"⚠️ Prediction missing for {pred_file}")
            continue

        gt_depth = read_gt_depth(gt_path)
        if gt_depth is None:
            continue

        # Normalize GT to 0-255 uint8
        gt_norm = cv2.normalize(gt_depth, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)

        # Read predicted depth (already uint8)
        pred = cv2.imread(pred_path, cv2.IMREAD_GRAYSCALE)
        if pred is None:
            print(f"❌ Failed to read prediction: {pred_file}")
            continue

        pred_resized = cv2.resize(pred, (gt_norm.shape[1], gt_norm.shape[0]))

        # Convert to float32 for metrics
        gt_f = gt_norm.astype("float32")
        pred_f = pred_resized.astype("float32")

        # Core metric calculations
        rmse = np.sqrt(np.mean((gt_f - pred_f) ** 2))
        mae = np.mean(np.abs(gt_f - pred_f))
        nrmse = rmse / (gt_f.max() - gt_f.min() + 1e-5)
        mape = np.mean(np.abs((gt_f - pred_f) / (gt_f + 1e-5))) * 100
        corr = np.corrcoef(gt_f.flatten(), pred_f.flatten())[0, 1]

        # Append all
        metrics["RMSE"].append(rmse)
        metrics["MAE"].append(mae)
        metrics["NRMSE"].append(nrmse)
        metrics["MAPE"].append(mape)
        metrics["SSIM"].append(ssim(gt_norm, pred_resized))
        metrics["PSNR"].append(psnr(gt_norm, pred_resized))
        metrics["Correlation"].append(corr)

    if all(len(v) > 0 for v in metrics.values()):
        final_scores = {k: round(np.mean(v), 2) for k, v in metrics.items()}
        metrics_path = os.path.join(OUTPUT_ROOT, scene_name, "metrics.txt")
        with open(metrics_path, "w") as f:
            f.write(str(final_scores))
        print(f"📊 Metrics saved for {scene_name}: {final_scores}")
    else:
        print(f"⚠️ No valid comparisons for {scene_name}")

# === MAIN LOOP ===
for scene in os.listdir(SCENE_ROOT):
    scene_path = os.path.join(SCENE_ROOT, scene)
    gt_dir = os.path.join(scene_path, "dslr_images")
    pred_dir = os.path.join(OUTPUT_ROOT, scene, "midas_depth")

    if not os.path.exists(gt_dir):
        print(f"⚠️ No ground truth folder in {scene}")
        continue
    if not os.path.exists(pred_dir):
        print(f"⚠️ No MiDaS outputs for {scene}")
        continue

    evaluate(scene, gt_dir, pred_dir)
