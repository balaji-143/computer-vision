import pytest
import os
import open3d as o3d
import cv2
import glob

def test_fused_pointcloud_quality():
    fused_path = "outputs/courtyard/dense/fused.ply"
    assert os.path.exists(fused_path), "fused.ply not found"
    pcd = o3d.io.read_point_cloud(fused_path)
    assert len(pcd.points) > 10000, "Too few points in the fused scene"

def test_midas_depth_maps_exist_and_are_readable():
    depth_dir = "outputs/courtyard/midas_depth"
    depth_maps = sorted(glob.glob(os.path.join(depth_dir, "*.png")))
    assert len(depth_maps) >= 5, "Not enough depth maps found"
    
    for img_path in depth_maps:
        img = cv2.imread(img_path, cv2.IMREAD_UNCHANGED)
        assert img is not None, f"Depth map {img_path} could not be read"
