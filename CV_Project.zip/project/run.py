import streamlit as st
import os
import glob
import subprocess

st.set_page_config(layout="wide")
st.title("🌍 ETH3D Scene Explorer")

# 📁 Scene selection
scene_root = "outputs"
scenes = sorted([d for d in os.listdir(scene_root) if os.path.isdir(os.path.join(scene_root, d))])
selected_scene = st.selectbox("🔽 Select Scene", scenes)

# 📌 Paths
scene_path = os.path.join(scene_root, selected_scene)
fused_path = os.path.join(scene_path, "dense", "fused.ply")
depth_path = os.path.join(scene_path, "midas_depth")
metrics_path = os.path.join(scene_path, "metrics.txt")
original_images_path = os.path.join("data", "eth3d", selected_scene, "images")

# 📊 Evaluation Metrics Sidebar
st.sidebar.markdown("""
    <div style="background-color:#0e1117;padding:20px 10px 10px 10px;border-radius:10px;">
        <h2 style='color:white; font-size:28px; text-align:center;'>📊 Evaluation Metrics</h2>
""", unsafe_allow_html=True)

if os.path.exists(metrics_path):
    try:
        with open(metrics_path, "r") as f:
            content = f.read().replace("{", "").replace("}", "")
            for line in content.replace(",", "\n").splitlines():
                if ":" in line:
                    key, val = line.strip().split(":")
                    key = key.strip().strip("'\"")
                    val = val.strip().replace("np.float32", "").replace("np.float64", "").replace("(", "").replace(")", "").strip()
                    st.sidebar.markdown(f"<p style='font-size:20px; margin:10px 0;'><b>{key}:</b> {val}</p>", unsafe_allow_html=True)
    except Exception:
        st.sidebar.warning("⚠️ metrics.txt found but unreadable.")
else:
    st.sidebar.warning("⚠️ metrics.txt not found or improperly formatted.")

st.sidebar.markdown("</div>", unsafe_allow_html=True)

# 🕶️ Show 3D Scene
if st.button("🕶️ Show 3D Scene"):
    if os.path.exists(fused_path):
        st.success("✅ Opening 3D Scene in Open3D window...")
        python_exe = os.popen("which python").read().strip()
        viewer_code = f"""
import open3d as o3d
pcd = o3d.io.read_point_cloud(r\"\"\"{fused_path}\"\"\")
o3d.visualization.draw_geometries([pcd])
"""
        with open("launch_viewer.py", "w") as f:
            f.write(viewer_code)
        subprocess.Popen([python_exe, "launch_viewer.py"])
    else:
        st.error("❌ fused.ply not found for this scene.")

# 🧠 Show MiDaS Depth Maps
if st.button("🧠 Show MiDaS Depth Maps"):
    if os.path.exists(depth_path):
        imgs = sorted(glob.glob(os.path.join(depth_path, "*.png")))
        if imgs:
            st.markdown("### 🖼️ MiDaS Depth Maps")
            cols = st.columns(3)
            for i, img in enumerate(imgs):
                cols[i % 3].image(img, caption=os.path.basename(img), use_container_width=True)
        else:
            st.warning("⚠️ No depth maps found.")
    else:
        st.warning("⚠️ MiDaS folder not found.")

# 📸 Show Original Dataset Images
if st.button("📸 Show Original DSLR Images"):
    if os.path.exists(original_images_path):
        imgs = sorted(glob.glob(os.path.join(original_images_path, "*.JPG")))
        if imgs:
            st.markdown("### 🏞️ Original Dataset Images")
            cols = st.columns(3)
            for i, img in enumerate(imgs):
                cols[i % 3].image(img, caption=os.path.basename(img), use_container_width=True)
        else:
            st.warning("⚠️ No JPG images found.")
    else:
        st.warning("⚠️ DSLR image folder not found for this scene.")
