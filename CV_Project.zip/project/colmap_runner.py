import os
import subprocess

def run_colmap(scene_path, out_path):
    img_dir = os.path.join(scene_path, "images")
    db = os.path.join(out_path, "colmap.db")
    sparse = os.path.join(out_path, "sparse")
    dense = os.path.join(out_path, "dense")

    os.makedirs(out_path, exist_ok=True)
    os.makedirs(sparse, exist_ok=True)
    os.makedirs(dense, exist_ok=True)

    def cmd(args):
        print("⚙️ Running:", " ".join(args))
        subprocess.run(args, check=True)

    # 1. Feature extraction & matching
    cmd(["colmap", "feature_extractor", "--database_path", db, "--image_path", img_dir])
    cmd(["colmap", "exhaustive_matcher", "--database_path", db])

    # 2. Sparse reconstruction
    cmd(["colmap", "mapper", "--database_path", db, "--image_path", img_dir, "--output_path", sparse])

    # ✅ Check for sparse/0 (first model)
    sparse_model = os.path.join(sparse, "0")
    if not all(os.path.exists(os.path.join(sparse_model, f)) for f in ["cameras.bin", "images.bin", "points3D.bin"]):
        print("❌ Sparse reconstruction failed — skipping further steps.")
        return

    # 3. Undistort images
    cmd(["colmap", "image_undistorter",
         "--image_path", img_dir,
         "--input_path", sparse_model,
         "--output_path", dense,
         "--output_type", "COLMAP"])

    # 4. Try Dense stereo only if CUDA available
    try:
        cmd(["colmap", "patch_match_stereo", "--workspace_path", dense, "--workspace_format", "COLMAP"])
        cmd(["colmap", "stereo_fusion",
             "--workspace_path", dense,
             "--workspace_format", "COLMAP",
             "--input_type", "geometric"])
    except subprocess.CalledProcessError as e:
        print("⚠️ Skipping dense stereo & fusion — likely due to lack of CUDA (expected on macOS).")
